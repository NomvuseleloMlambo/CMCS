﻿using Microsoft.AspNetCore.Mvc;
using CMCS.Data;
using CMCS.Models;
using System.Linq;

namespace CMCS.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var claims = _context.LecturerClaims.ToList();
            return View(claims);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(LecturerClaim claim)
        {
            if (ModelState.IsValid)
            {
                _context.LecturerClaims.Add(claim);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(claim);
        }

        public IActionResult Details(int id)
        {
            var claim = _context.LecturerClaims.FirstOrDefault(c => c.Id == id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim);
        }
    }
}
