﻿using Microsoft.AspNetCore.Mvc;

namespace CMCS.Controllers
{
    public class ProfileController : Controller
    {
        public IActionResult Update()
        {
            return View();
        }

        public IActionResult Logout()
        {
            return View();
        }
    }
}

