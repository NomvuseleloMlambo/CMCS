﻿using Microsoft.AspNetCore.Mvc;
using CMCS.Models;
using CMCS.ViewModels;

namespace CMCS.Controllers
{
    public class LecturerController : Controller
    {
        private static List<LecturerClaim> claims = new List<LecturerClaim>();

       
        public IActionResult Dashboard()
        {
            return View(claims); 
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SubmitClaim(NewClaimViewModel model)
        {
            if (ModelState.IsValid)
            {
                var newClaim = new LecturerClaim
                {
                    Id = claims.Count + 1,
                    LecturerName = model.LecturerName,
                    HoursWorked = model.HoursWorked,
                    HourlyRate = (double)model.HourlyRate, 
                    Notes = model.Notes,
                    SupportingDocument = model.SupportingDocument
                };

                claims.Add(newClaim); 
                return RedirectToAction("Dashboard"); 
            }

            return View(model); 
        }

        public IActionResult ViewClaim(int id)
        {
            var claim = claims.FirstOrDefault(c => c.Id == id);
            if (claim == null)
            {
                return NotFound(); 
            }

            return View(claim); 
        }
    }
}
