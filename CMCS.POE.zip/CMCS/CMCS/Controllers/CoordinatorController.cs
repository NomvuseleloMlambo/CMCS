﻿using Microsoft.AspNetCore.Mvc;
using CMCS.Data;
using CMCS.Models;
using System.Linq;

namespace CMCS.Controllers
{
    public class CoordinatorController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CoordinatorController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult ClaimsList()
        {
            var claims = _context.LecturerClaims.ToList();
            return View(claims);
        }

        public IActionResult ApproveClaim(int id)
        {
            var claim = _context.LecturerClaims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = "Approved";
                _context.SaveChanges();
            }
            return RedirectToAction("ClaimsList");
        }

        public IActionResult RejectClaim(int id)
        {
            var claim = _context.LecturerClaims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = "Rejected";
                _context.SaveChanges();
            }
            return RedirectToAction("ClaimsList");
        }
    }
}
