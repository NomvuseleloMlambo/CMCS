﻿namespace CMCS.ViewModels
{
    public class NewClaimViewModel
    {
        public string LecturerName { get; set; }
        public int HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string Notes { get; set; }
        public string SupportingDocument { get; set; }
    }
}

