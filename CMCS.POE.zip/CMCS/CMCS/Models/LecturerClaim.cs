﻿using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class LecturerClaim
    {
        public int Id { get; set; }
        public string LecturerName { get; set; }
        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }
        public string Notes { get; set; }
        public string? SupportingDocument { get; set; }
        public string Status { get; set; } 

   
        public double TotalPayment => HoursWorked * HourlyRate;
    }
}


