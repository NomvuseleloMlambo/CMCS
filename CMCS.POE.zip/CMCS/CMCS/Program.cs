using CMCS.Data;
using CMCS.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseInMemoryDatabase("ClaimsDb")); 


builder.Services.AddControllersWithViews();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}



using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<ApplicationDbContext>();
    SeedData(context);  
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();


void SeedData(ApplicationDbContext context)
{
    if (!context.LecturerClaims.Any())
    {
        context.LecturerClaims.AddRange(
            new LecturerClaim
            {
                LecturerName = "Angie Smith",
                HoursWorked = 10,
                HourlyRate = 50,
                Notes = "Lecture preparation",
                Status = "Pending",
                SupportingDocument = null
            },
            new LecturerClaim
            {
                LecturerName = "Eric Browne",
                HoursWorked = 8,
                HourlyRate = 60,
                Notes = "Guest lecture",
                Status = "Approved",
                SupportingDocument = null
            }
        );
        context.SaveChanges();
    }
}
