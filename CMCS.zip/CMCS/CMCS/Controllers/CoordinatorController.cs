﻿using Microsoft.AspNetCore.Mvc;

namespace CMCS.Controllers
{
    public class CoordinatorController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }

        public IActionResult ClaimsList()
        {
            return View();
        }
    }
}

