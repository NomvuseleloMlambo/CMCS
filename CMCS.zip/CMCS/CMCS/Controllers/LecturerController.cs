﻿using Microsoft.AspNetCore.Mvc;

namespace CMCS.Controllers
{
    public class LecturerController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }

        public IActionResult SubmitClaim()
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }

        public IActionResult StatusUpdates()
        {
            return View();
        }

        public IActionResult ClaimHistory()
        {
            return View();
        }

        public IActionResult Notifications()
        {
            return View();
        }
    }
}


